import logo from './logo.svg';
import Bar from './comp/bar';
import './App.css';
import New from './comp/new';

function App() {
  return (
    <div className="App">

    <Bar/>
    <New/>
    </div>
  );
}

export default App;
