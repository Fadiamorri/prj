const Bar=()=>{
    return(
        <div className="z1" >
            <img alt=""/>
            <div  className="z2" >
                <a className="z2" href="">Home</a>
                <a className="z2" href="">Livre</a>
                <a className="z2" href="">Contact</a>
            </div>
            
            
        </div>
    )
}
export default Bar;