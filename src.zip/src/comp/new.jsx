
import React, { useState } from 'react';




const New=()=>{
 
 
  const [image, setImage] = useState(null);
  const loadfile = (event) => {
    const imageUrl = URL.createObjectURL(event.target.files[0]);
    setImage(imageUrl);
   ;
  };
  const [title, setTitle] = useState("");
  function newliv(){
    
    const newDiv = document.createElement('div');
    const newImg= document.createElement('img');
    const newTitle = document.createElement('h3');
    const newDisc = document.createElement('p');
    const newButt = document.createElement('button');
    const newButtrm = document.createElement('button');
    

  

    newDiv.className = 'z4';
    newDiv.id = document.getElementById("title").value;
    newImg.src= image;
    newImg.className = "z199";
    newTitle.innerHTML = document.getElementById("title").value;
    newDisc.innerHTML = document.getElementById("des").value;
    newButt.innerHTML = 'Read Now';
    newButtrm.innerHTML = 'Remove Book';

    

    const f= document.getElementById('f');
  

    newDiv.appendChild(newImg);
    newDiv.appendChild(newTitle);
    newDiv.appendChild(newDisc);
    newDiv.appendChild(newButt);
    newDiv.appendChild(newButtrm);
    f.appendChild(newDiv);}
    return(
  
        <div class="z100" id='f'>
      
          <div class="z4" >
            <div  className="z0">
              <label className="z0">select book poster</label>
              <input onchange={loadfile} type="file" id="file" className="z0" ></input>
              <label><br></br>insert a title of the book</label>
              <input type="text" placeholder='Book Title' id="title"/>
              <label><br></br><br></br>insert a description of the book</label>
              <input type="text" placeholder='Book Description' id="des"/><br></br><br></br>
              <button onClick={newliv}>Add Book</button>
              <button >Remove Book</button>
           
            </div>


          </div>
            <div  class="z4">
              <img   class="z10"></img>
              <h3>LA GRANDE GUERRE</h3>
              <p>book Description</p>
              <button>Read Now</button>
              <button >Remove Book</button>
              
              
            </div>
            <div  class="z4">
              <img   class="z20"></img>
              <h3>THE TREE</h3>
              <p>book Description</p>
              <button >Read Now</button>
              <button >Remove Book</button>
            
            </div>
             <div  class="z4">
              <img class="z30"></img>
              <h3>ANIMALIA</h3>
              <p>book Description</p>
              <button >Read Now</button>
              <button >Remove Book</button>
        
            </div>
        
          
        </div>
        
       
  );

    
}
export default New;